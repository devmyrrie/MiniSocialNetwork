#include "UnitTest++.h"
#include <cstdio>
using namespace std;
int main()
{
   freopen("SALIDA.txt","w",stdout);

    return UnitTest::RunAllTests();

}
